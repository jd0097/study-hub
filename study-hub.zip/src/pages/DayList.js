import React from "react";

const DayList = () => {
  return <div>Day-list</div>;
};

export default DayList;
