import styled  from "@emotion/styled";


  const StudyPlanDiv = styled.div`
  button {
    background-color: #f5f5f5;
    padding: 16px;
    text-align: center;
    item
  }
  `;

 
 export default StudyPlanDiv;