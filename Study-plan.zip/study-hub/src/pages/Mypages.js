import React from 'react'

const Mypages = () => {
  return (
    <div>Mypages</div>
  )
}

export default Mypages