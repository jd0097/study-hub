import React from "react";

const Write = () => {
  return <div>Write</div>;
};

export default Write;
