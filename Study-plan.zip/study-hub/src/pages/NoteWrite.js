import React from 'react'

const NoteWrite = () => {
  return (
    <div>NoteWrite</div>
  )
}

export default NoteWrite