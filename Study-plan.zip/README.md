# Study Hub




<!-- About the Project -->

##  About the Project

### 프로젝트 인원

팀장 정다혜

팀원 이상윤


### 웹애플리케이션 제작 목적

- 



### 작업기간

2023-06-26 ~ 2023-07-10


<!-- Getting Started -->

### 활용 기술

<img src="https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=HTML5&logoColor=white" /> <img src="https://img.shields.io/badge/CSS3-1572B6?style=flat&logo=CSS3&logoColor=white" /> <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=flat&logo=JavaScript&logoColor=white" /> <img src="https://img.shields.io/badge/React-61DAFB?style=flat&logo=React&logoColor=white" /> <img src="https://img.shields.io/badge/SCSS-CC6699?style=flat&logo=Sass&logoColor=white" />

<img src="https://img.shields.io/badge/GitHub-181717?style=flat&logo=GitHub&logoColor=white" /> <img src="https://img.shields.io/badge/Sourcetree-0052CC?style=flat&logo=Sourcetree&logoColor=white" /> <img src="https://img.shields.io/badge/Notion-000000?style=flat&logo=Notion&logoColor=white" /> <img src="https://img.shields.io/badge/YouTube Library-FF0000?style=flat&logo=YouTube&logoColor=white" /> <img src="https://img.shields.io/badge/React Router-CA4245?style=flat&logo=reactrouter&logoColor=white" />

fontawesome
tailwind
axios
antDesig
react calender
eslint
prettier


<!-- Features -->

### 프로젝트 후기


