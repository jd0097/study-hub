import React from "react";

const StudyWrite = () => {
  return <div>StudyWrite</div>;
};

export default StudyWrite;
