import React from "react";

const StudyWrite = () => {
  return <div>
    
  </div>;
};

export default StudyWrite;
