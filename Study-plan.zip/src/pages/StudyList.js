import React from "react";

const StudyList = () => {
  return (
    <div className="study_list_warp">
      <h1 className="title">STUDY LIST</h1>
      <div className="study_inner">
        <div className="timer_date">
          <div className="today"></div>
          <div className="timer"></div>
        </div>
      </div>
    </div>
  );
};

export default StudyList;
