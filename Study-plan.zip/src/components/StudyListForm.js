import React from "react";

const StudyListForm = () => {
  return (
    <div className="study_list_form">
      <ul className="study_list">
        <li>
          <span className="category">국어</span>
          <span className="list_title">
            <p>국어 1장</p>
            <button className="list_delete">삭제</button>
          </span>
        </li>
      </ul>
    </div>
  );
};

export default StudyListForm;
